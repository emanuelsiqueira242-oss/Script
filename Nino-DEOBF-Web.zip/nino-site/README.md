# Nino DEOBF Web

Interface web para o motor de **desofuscação Prometheus** presente no ZIP fornecido.

> Importante: este projeto não transforma qualquer Lua em código legível. O motor original faz detecção de payload Prometheus e possui uma pipeline específica de desofuscação. A opção **Forçar análise** pula a detecção.

## Rodar

Requer Node.js 18+.

```bash
npm start
```

Abra `http://localhost:3000`.

## Estrutura

- `public/` — interface mobile/desktop
- `server.js` — API HTTP
- `engine/` — código do motor reorganizado a partir do ZIP

O servidor limita entradas a 5 MB e não executa o Lua recebido; ele apenas processa o código através do parser/pipeline JavaScript do projeto.
